package setup;

public class VoSetup {
	
	//원시변수
	
	//참조변수
	
	//생성자[필요할경우 추가로 기입]
	
	//getter , setter

}
