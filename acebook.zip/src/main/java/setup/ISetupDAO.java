package setup;

public interface ISetupDAO {
	
	void save();
	//Setup findBySn(int sn);
	//List<Setup> sellectAll();

}
