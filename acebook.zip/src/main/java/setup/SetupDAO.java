package setup;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

//@Repository
public class SetupDAO implements ISetupDAO {

	//@Autowired ISetupMapper setupMapper;
	
	@Override
	@Transactional
	public void save() {

	//setupMapper.setup(obj);
			
	}
		
}
