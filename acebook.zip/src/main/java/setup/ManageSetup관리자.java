package setup;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.lec206.acebook.util.BusinessResult;

//@Service
public class ManageSetup관리자 implements IManageSetup관리 {

	//@Autowired ISetupDAO setupDAO;
	
	@Override
	@Transactional
	public BusinessResult setup() {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부()
		
		return new BusinessResult();

	}

	@Override
	@Transactional
	public BusinessResult setup(Object obj) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부()
		
		return new BusinessResult(obj);

	}

	@Override
	public BusinessResult hashmap(Object obj) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부()
		try {
			
		} catch(Exception e) { 

			//수동rollback
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return null;
	}

}