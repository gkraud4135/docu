package config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.lec206.acebook")
public class MvcConfig implements WebMvcConfigurer {

	public void configureViewResolvers(ViewResolverRegistry registry) {
		
		registry.jsp("/WEB-INF/views/",".jsp");
	
	}
	
  public void addResourceHandlers(final ResourceHandlerRegistry registry) {
		  
		 registry.addResourceHandler("/img/**").addResourceLocations("/img/");
		 registry.addResourceHandler("/js/*.js").addResourceLocations("/js/");
		 registry.addResourceHandler("/css/*.css").addResourceLocations("/css/");
			  
	}
  
  /* 인터셉터 추가시 참고 , 프로젝트 진행시 로그인있으면 귀찮아서 일딴 주석처리해둠
  @Override
  public void addInterceptors(InterceptorRegistry registry) {
  																			
  	registry.addInterceptor(new LoginInterceptor()).addPathPatterns("/*").excludePathPatterns("/member").excludePathPatterns("/main")
  	.excludePathPatterns("/login").excludePathPatterns("/id_isin");
  	
  	
  	}
	   */
	}