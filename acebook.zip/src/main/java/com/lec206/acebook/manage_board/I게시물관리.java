package com.lec206.acebook.manage_board;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lec206.acebook.common_board.Attach;
import com.lec206.acebook.common_board.Board;
import com.lec206.acebook.common_board.Comment;
import com.lec206.acebook.util.BusinessResult;

public interface I게시물관리 {
	
	//return : notting
	BusinessResult 게시물등록준비();
	
	//return : notting
	BusinessResult 게시물저장(Board board);
	
	//return : List<Board> boards
	BusinessResult 개인게시물(int sn,int size);
	
	//return : List<Attach> attachs	
	BusinessResult 첨부파일가져오기(int boardsn);
	
	//return : List<BoardLike> boardlike
	BusinessResult 좋아요정보(int sn);// 좋아요정보
	
	//return : int likes
	BusinessResult 좋아요s(int sn);//좋아요 갯수
	
	//return : notting
	BusinessResult 좋아요OnOff(int bno, int mno,int no); //좋아요 실행
	
	//return : int likeis
	BusinessResult 좋아요is(int bno, int mno); //좋아요 여부
	
	//return : List<Comment> commentlist
	BusinessResult 댓글출력(int sn,int size); //댓글 출력

	//return : int comments
	public BusinessResult 댓글갯수(int sn); //댓글수 출력
	
	//return : Comment comment
	BusinessResult 댓글등록후출력(Comment comment); //댓글등록 그댓글 출력

	//return : notting
	BusinessResult 댓글삭제(int sn); //댓글등록 그댓글 출력
	
	//return : List<Board> boards
	BusinessResult mainboard(int sn,int size); //댓글등록 그댓글 출력
	
	//return : notting
	BusinessResult viewtimeupdate(int sn); //view시간 변경
	
	//return : List<Board> boards
	BusinessResult randomboard(); //전체 게시물 랜덤출력

	//return : int 갯수
	BusinessResult checknewboard(int sn); //새로생긴보드갯수확인
	
	//return : int 갯수
	BusinessResult numberofboard(int sn); //전체 게시물갯수
	
	//return : Attach 광고
	BusinessResult Advertising(); //광고 게시물출력
	
	//return : notting
	BusinessResult deleteboard(int sn); //게시물 삭제
	
	//return : Board board
	BusinessResult findboard(int sn); //게시물출력
	
	//return : notting
	BusinessResult deleteAttach(int sn,HttpServletRequest req); //첨부파일 삭제
	
	//return : notting
	BusinessResult modifyboard(Board board); //게시물수정
	
	//return : notting
	BusinessResult reportboard(int sn); //게시물신고
	
	//return : Board board
	BusinessResult sharing(int sn); //게시물공유

	//return : int getsn
	BusinessResult 공유첨부파일(int sn); //게시물공유
	
}
