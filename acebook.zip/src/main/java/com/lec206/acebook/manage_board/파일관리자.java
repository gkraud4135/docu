package com.lec206.acebook.manage_board;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.lec206.acebook.common_board.Attach;
import com.lec206.acebook.common_board.Board;
import com.lec206.acebook.dataservice_board.IBoardDAO;
import com.lec206.acebook.util.BusinessResult;

@Service
public class 파일관리자 implements I파일관리 {
	
	@Autowired IBoardDAO boardDAO;
	
	   @Override
	   @Transactional
	   public BusinessResult 파일업로드(Board board, String id, String path) {
		   		
		   	System.out.println(board.getSn()+"<-게시물번호");
		   	
		   	String 저장경로 = path+"//"+id+"//"+board.getSn();
	         
	         File folder=new File(저장경로);
	         
	         folder.mkdirs();
	         
	         for(MultipartFile multipartfile : board.getAttachFiles()) {
	            
	            File 첨부파일 = new File(저장경로+"//"+multipartfile.getOriginalFilename());
	            
	            System.out.println(첨부파일+"<-파일저장경로확인");
	            
	         try {
	               
	            multipartfile.transferTo(첨부파일);
	                     
	            } catch (Exception e) {System.out.println("첨부파일에 문제가 생겼어요!");}
	                  
	         }
	      
	      return new BusinessResult();
	   }
	   
	   @Override
	   @Transactional
	   public void 사진출력(int 첨부번호,HttpServletRequest req, HttpServletResponse rep) {
		   try {
		    	 String encodedFilename="";
		    	 String fullFilePath =null;	
		         String path = req.getSession().getServletContext().getRealPath("/upload/board");	
		         
		         
		    	 if(첨부번호!=0) {
		         Attach attach=boardDAO.findBySn(첨부번호);
		         System.out.println("아이디"+attach.getBoard().getWriter().getId());
		         String filename = attach.getFilename();
		        
		         String browser = req.getHeader("User-Agent"); 
		         System.out.println(browser);
		         if (browser.contains("MSIE")||browser.contains("Chrome")) {
		         encodedFilename = URLEncoder.encode(filename, "UTF-8").replaceAll("\\+", "%20");
		         } else if (browser.contains("Firefox")) {
		         encodedFilename = "\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		         } else if (browser.contains("Opera")) {
		         encodedFilename = "\"" + new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		         }
	  
								   
		         fullFilePath=path+"//"+attach.getBoard().getWriter().getId()+"//"+attach.getBoard().getSn()+"//"+attach.getFilename();
		         }
		    	 else{fullFilePath=path+"//"+"noimage.png";}
		    	 		//upload/board/bono.jpg에서 호출
		         rep.setContentType("application/octer-stream: charset=utf-8");
		         rep.setHeader("Content-Transfer-Encoding", "binary");     
		         rep.setHeader("Content-Disposition",
		         "attachment; filename=\""+encodedFilename+"\"");
		         File file=new File(fullFilePath);
		         rep.setHeader("Content-Length", "" + file.length());
		        
		         OutputStream os =rep.getOutputStream();
		         FileInputStream fis=new FileInputStream(file);
		         int 읽은크기=0;
		         byte [] 버퍼 = new byte[1024];
		         while((읽은크기=fis.read(버퍼))!=-1) {//fis가 HDD 파일을 읽어 메모리 버퍼로  데이터 이동
		         os.write(버퍼,0,읽은크기); //os가 메모리 버퍼에서 응답 버퍼로  데이터 이동
		         }
		         fis.close();
		         os.close();
		         }catch(Exception ex) {ex.printStackTrace();}
		   
	   }

	}