package com.lec206.acebook.manage_board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lec206.acebook.common_board.Board;
import com.lec206.acebook.util.BusinessResult;

public interface I파일관리 {
	
	BusinessResult 파일업로드(Board board,String id,String path);
	
	//수정해야함
	public void 사진출력(int 첨부번호,HttpServletRequest req, HttpServletResponse rep);
}