package com.lec206.acebook.manage_board;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lec206.acebook.common_board.Attach;
import com.lec206.acebook.common_board.Board;
import com.lec206.acebook.common_board.BoardLike;
import com.lec206.acebook.common_board.Comment;
import com.lec206.acebook.dataservice_board.IBoardDAO;
import com.lec206.acebook.dataservice_member.IMemberDAO;
import com.lec206.acebook.util.BusinessResult;
import com.lec206.acebook.util.게시물상태;


@Service
public class 게시물관리자 implements I게시물관리 {

	@Autowired IBoardDAO boardDAO;
	@Autowired IMemberDAO memberDAO;
	
	@Override
	@Transactional
	public BusinessResult 게시물등록준비() {
		
		// ERROR
		
		return new BusinessResult();
	}
	
	@Override
	@Transactional
	public BusinessResult 게시물저장(Board board) {
		
		//업무
		
		//1-1업무규칙검사(들어온 게시물 저장)
	
		//1-2업무실행

		//DB이용여부(boardDAO.save())
		
		boardDAO.save(board);
		
		if(board.getState()==게시물상태.프로필) {	//첨부파일번호, 회원번호
			
			int sn = boardDAO.findattachsn(board.getSn());
			memberDAO.changeProfile(sn,board.getWriter().getSn());
		}
		if(board.getState()==게시물상태.백프로필) {
			
			int sn = boardDAO.findattachsn(board.getSn());
			memberDAO.changeBackProfile(sn,board.getWriter().getSn());
		}
		
		return new BusinessResult();

	}

	
	@Override
	@Transactional
	public BusinessResult 개인게시물(int sn,int size) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부()
		List<Board> boards = boardDAO.myboard(sn,size);

		return new BusinessResult(boards);
	}

	@Override
	@Transactional
	public BusinessResult 첨부파일가져오기(int boardsn) {

		//DB이용여부(boardDAO.load)
		
		//업무
		List<Attach> attachs = null;
		
		//1-1업무규칙검사
		attachs = boardDAO.load(boardsn);
		
		if(attachs.size()!=0) {
			
			System.out.println("첨부파일이 있어요!");
			return new BusinessResult(attachs);
			
		}

		//1-2업무실행
		//첨부파일이 없을경우 그냥 리턴함
		return new BusinessResult(); 
		
	}
	
	@Override
	@Transactional
	public BusinessResult 좋아요정보(int sn) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부
		List<BoardLike> boardlike = boardDAO.boardlike(sn);
		return new BusinessResult(boardlike);

	}
	
	@Override
	@Transactional
	public BusinessResult 좋아요s(int sn) {
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부
		int likes = boardDAO.likes(sn);
		return new BusinessResult(likes);
	}
	
	@Override
	@Transactional
	public BusinessResult 좋아요OnOff(int bno, int mno,int no) {
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부
		boardDAO.onoffLike(bno, mno, no);
		return new BusinessResult();
	}
	
	@Override
	@Transactional
	public BusinessResult 좋아요is(int bno, int mno) {
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부
		int likeis = boardDAO.likeis(bno, mno);
		return new BusinessResult(likeis);
	}
	
	@Override
	@Transactional
	public BusinessResult 댓글출력(int sn,int size) {
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부
		List<Comment> commentlist = boardDAO.findCommentBySn(sn,size);
		return new BusinessResult(commentlist);
	}

	@Override
	@Transactional
	public BusinessResult 댓글갯수(int sn) {
		
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부
		int comments = boardDAO.comments(sn);
		return new BusinessResult(comments);
	}
	
	@Override
	@Transactional
	public BusinessResult 댓글등록후출력(Comment comment) {
		//업무
		//1-1업무규칙검사
		
		//1-2업무실행
		//DB이용여부
		boardDAO.savecomment(comment);//게시물등록후 pk 리턴
		Comment mycomment = boardDAO.findComment(comment.getSn());//pk로 해당 댓글 리턴
		return new BusinessResult(mycomment);
	}
	
	@Override
	@Transactional
	public BusinessResult 댓글삭제(int sn) {
		//업무
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부
		boardDAO.deletecomment(sn);
		return new BusinessResult();

	}
	
	@Override
	@Transactional
	public BusinessResult mainboard(int sn,int size) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부()
		
		List<Board> boards = boardDAO.mainboard(sn,size);

		return new BusinessResult(boards);
	}
	
	@Override
	@Transactional
	public BusinessResult viewtimeupdate(int sn) {
		
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부()
		boardDAO.viewtimeupdate(sn);
		return new BusinessResult();
	}
	
	@Override
	@Transactional
	public BusinessResult randomboard() {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부()
		
		List<Board> boards = boardDAO.selectAll();

		return new BusinessResult(boards);
	}
	
	@Override
	@Transactional
	public BusinessResult checknewboard(int sn) {
		
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부()
		int 갯수 = boardDAO.checknewboard(sn);
		return new BusinessResult(갯수);
	}
	
	@Override
	@Transactional
	public BusinessResult numberofboard(int sn) {
		
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부()
		int 갯수 = boardDAO.numberofboard(sn);
		return new BusinessResult(갯수);
	}

	@Override
	@Transactional
	public BusinessResult Advertising() {
		
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부()
		Attach 광고 = boardDAO.Advertising();
		return new BusinessResult(광고);
	}
	
	@Override
	@Transactional
	public BusinessResult deleteboard(int sn) {
		
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부()
		int getsn = 0;
		try {getsn = (int)boardDAO.getsharingsn(sn);}catch(Exception e){}
		if (getsn !=0) {boardDAO.deletesharing(sn);}
		boardDAO.deleteboard(sn);
		return new BusinessResult();
	}
	
	@Override
	@Transactional
	public BusinessResult findboard(int sn) {
		
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		
		//DB이용여부()
		Board board  = boardDAO.findboard(sn);
		return new BusinessResult(board);
	}
	
	@Override
	@Transactional
	public BusinessResult deleteAttach(int sn,HttpServletRequest req) {
		
		//업무
		
		//1-1업무규칙검사
		
		//1-2업무실행
		String filePath =null;	
		String path = req.getSession().getServletContext().getRealPath("/upload/board");
        Attach attach=boardDAO.findBySn(sn);
        filePath=path+"//"+attach.getBoard().getWriter().getId()+"//"+attach.getBoard().getSn()+"//"+attach.getFilename();

        File deleteFile = new File(filePath);
 
        // 파일이 존재하는지 체크 존재할경우 true, 존재하지않을경우 false
        if(deleteFile.exists()) {
            
            // 파일을 삭제합니다.
            deleteFile.delete(); 
            
            System.out.println("파일을 삭제하였습니다.");
            
        } else {
            System.out.println("파일이 존재하지 않습니다.");
        }
		//DB이용여부()
		boardDAO.deleteAttach(sn);//db삭제
		return new BusinessResult();
	}
	
	@Override
	@Transactional
	public BusinessResult modifyboard(Board board) {
		//업무
		//1-1업무규칙검사
		//1-2업무실행
		//DB이용여부()
		boardDAO.modifyboard(board);
		
		return new BusinessResult();
	}
	
	@Override
	@Transactional
	public BusinessResult reportboard(int sn) {
		//업무
		//1-1업무규칙검사
		//1-2업무실행
		//DB이용여부()
		boardDAO.reportboard(sn);
		
		return new BusinessResult();
	}
	
	@Override
	@Transactional
	public BusinessResult sharing(int sn) {
		//업무
		//1-1업무규칙검사
		//1-2업무실행
		//DB이용여부()
		int getsn = boardDAO.getsharingsn(sn);
		Board board  = boardDAO.findboard(getsn);
		return new BusinessResult(board);
	}
	
	@Override
	@Transactional
	public BusinessResult 공유첨부파일(int sn) {
		//업무
		//1-1업무규칙검사
		//1-2업무실행
		//DB이용여부()
		int getsn = boardDAO.getsharingsn(sn);
		return new BusinessResult(getsn);
	}
}