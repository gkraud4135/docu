package com.lec206.acebook.dataservice_member;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.lec206.acebook.common_friend.Friend;
import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.common_member.MemberPost;
import com.lec206.acebook.common_member.MemberSchool;

@Mapper
public interface IMemberMapper {
	
	
	/* id=unique 추가해줘야함.
	@Update("update member set state = '회원' where sn=#{sn}")
	void ok(String id);
	*/ 
	
	//일시이용{
	@Insert("insert into member(id,name,password,gender,age,state) values(#{id},#{name},#{password},#{gender},#{age},'회원')")
	void save(Member member);
	//void preparesave(Member nMember);
	//}

	//회원의 모든정보 검색하기 위한 Mapper
	@Select("select * from member where sn=#{sn}")
	Member findBySn(int sn);
	
	//회원의 단순정보를 검색하기 위한 Mapper
	@Select("select sn,name,age,friendcount,profile,backprofile from member where sn=#{sn}")
	Member findSimple(int sn);
	
	@Select("select * from member where state='회원'")
	List<Member> selectAll();
	
	@Select("select if(count(*)=1,1,0) from member where id=#{id}")  //count 값이 1이면 1 아니면 0  true false 나타내고싶을때
	boolean isIn(String id);//중복검사 
	
	//학교정보{
	@Insert("insert into memberschool(sn,row,middle,high,university) values(#{sn.sn},#{row},#{middle},#{high},#{university})")
	void schoolsave(MemberSchool memberschool);
	
	@Update("update memberschool set row=#{row},middle=#{middle},high=#{high},university=#{university} where sn=#{sn.sn}")
	void schoolupdate(MemberSchool memberschool);

	   @Select("Select * from memberschool where sn=#{sn}")
	   @Results(value= {
	      @Result(property = "sn.sn", column="sn"),
	      @Result(property = "row", column="row"),
	      @Result(property = "middle", column="middle"),
	      @Result(property = "high", column="high"),
	      @Result(property = "university", column="university")})
	   MemberSchool findSchool(@Param("sn") int sn);
	   
		@Select("Select if(count(*)=1,1,0) from memberschool where sn=#{sn}")
		int schoolcounter(@Param("sn") int sn);
		//학교정보}
	   
		
		//주소정보{
	   @Insert("insert into memberpost(sn,post,address,addresstail,birthplace) values(#{sn.sn},#{post},#{address},#{addresstail},#{birthplace})")
	   void postsave(MemberPost memberpost);
	   
	   @Update("update memberpost set post=#{post},address=#{address},addresstail=#{addresstail},birthplace=#{birthplace} where sn=#{sn.sn}")
	   void postupdate(MemberPost memberpost);

	   //회원 주소정보 확인
	   @Select("Select * from memberpost where sn=#{sn}")
	   @Results(value= {
			      @Result(property = "sn.sn", column="sn"),
			      @Result(property = "post", column="post"),
			      @Result(property = "address", column="address"),
			      @Result(property = "addresstail", column="addresstail"),
			      @Result(property = "birthplace", column="birthplace")})
	   MemberPost findPost(@Param("sn") int sn);
	   
		@Select("Select if(count(*)=1,1,0) from memberpost where sn=#{sn}")
		int postcounter(@Param("sn") int sn);
		//주소정보}
		
	   //친구관련{
	   @Update("Update member set friendcount = #{count} where sn=#{sn.sn}")
	   void refreshfriend(@Param("sn")Member sn, @Param("count")int count);
	   

	   @Select("Select friend_sn,state from friend where my_sn=#{sn} and state='친구'")
	   @Results(value = {
				@Result(property = "state", column = "state"),
				@Result(property = "friend_sn", column = "friend_sn", one=@One(select = "com.lec206.acebook.dataservice_member.IMemberMapper.findSnNameProfile"))})
	   List<Friend> findfriends(@Param("sn") int sn);

	   
	   @Select("Select sn,name,profile from member where sn=#{sn}")
	   Member findSnNameProfile(int sn);
	   
	   //친구관련}
	   
	   //인물검색{
	    @Select("select * from member where name LIKE '%${name}%'")
	    List<Member> selectuser(@Param("name") String name);
	    
	   //나이로 검색하는거는 약간 수정해야되는 부분이 잇음![저장이 년도로 되잇음] 저장방식교체 혹은, 다른 함수이용해야함.
	   //age의 값이 date형으로 등록되잇어서 약간만 수정하면될꺼같음 ex : age[yyyy]=이런식으로도 가능하지 않을까 싶음
	   //select name from member where year(age) = '1992'; 예시로 하나 작업해둿음 알아서들 짜맞춰봐~
	   @Select("select name from member where age=#{age}")
	   List<Member>ageSearch(@Param("age")int age);
	   

	   @Select("")
	   List<Member>postSearch(@Param("post")String post);
	   
	   @Select("")
	   List<Member>schoolSearch(@Param("school")String school);
	   
	   //인물검색 return을 List<Member>로 받을지 혹은 List<MemberPost,MemberSchool> 로 받을지는 상의해서 수정요망!
	   //인물검색}
	   
	   //attach번호등록
		@Update("update member set profile=#{profile} where sn=#{sn}")
		void changeProfile(@Param("profile")int profile,@Param("sn")int sn);
		
		//게시물 좋아요 누른 member 프로필사진과 이름 출력
	    @Select("select * from boardlike join member on boardlike.writer = member.sn where board_sn=${sn}")
	         @Results(value = {
	               @Result(property = "profile", column = "member.profile"),
	               @Result(property = "name", column = "member.name"),
	               })
	         List<Member> likelist(@Param("sn")int sn);//유저출력
	    
	    //attach번호등록
		@Update("update member set backprofile=#{profile} where sn=#{sn}")
		void changeBackProfile(@Param("profile")int profile,@Param("sn")int sn);
	   
}