package com.lec206.acebook.dataservice_member;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lec206.acebook.common_friend.Friend;
import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.common_member.MemberPost;
import com.lec206.acebook.common_member.MemberSchool;
import com.lec206.acebook.dataservice_contents.ILoginMapper;
import com.lec206.acebook.util.BusinessResult;

@Repository
public class MemberDAO implements IMemberDAO{
	
	@Autowired IMemberMapper memberMapper;
	@Autowired ILoginMapper loginMapper;
	
	@Override
	@Transactional
	public void save(Member member) {
		
		memberMapper.save(member);

	}
	
	@Override
	@Transactional
	public Member findSimple(int sn) {
		
		Member member = new Member();
		member = memberMapper.findBySn(sn);
		
		//회원로그인정보가 잇을경우 setLogin에 회원정보를 넣어줌
		if(loginMapper.findBySn(sn)!=null) {
			
			member.setLogin(loginMapper.findBySn(sn));
			
		}
		
		//회원학교정보 넣어줌
		if(memberMapper.findSchool(sn)!=null) {
			
			member.setSchool(memberMapper.findSchool(sn));
			
		}
		
		//회원주소정보가 잇을경우 넣어줌
		if(memberMapper.findPost(sn)!=null) {
			
			member.setPost(memberMapper.findPost(sn));
			
		}
		//친구정보도 귀찮아서 그냥 다넣엇음ㅋㅋ
		if(memberMapper.findfriends(sn).size()!=0) {
			
			member.setFriends(memberMapper.findfriends(sn));
			
		}

		return member;		
	}
	
	@Override
	@Transactional
	public List<Member> selectAll() {
		return memberMapper.selectAll();
	}

	@Override
	@Transactional
	public boolean isIn(String id) {
		
		return memberMapper.isIn(id);
		
	}

	@Override
	@Transactional
	public void schoolsave(MemberSchool memberschool) {
		
		memberMapper.schoolsave(memberschool);
		
	}

	@Override
	@Transactional
	public Member findBySn(int sn) {
		
		return memberMapper.findBySn(sn);
	}

	@Override
	@Transactional
	public void postsave(MemberPost memberpost) {
		
	      
	      memberMapper.postsave(memberpost);
		
	}

	@Override
	@Transactional
	public void schoolupdate(MemberSchool memberschool) {
			
		memberMapper.schoolupdate(memberschool);
		
	}

	@Override
	@Transactional
	public void postupdate(MemberPost memberpost) {

		memberMapper.postupdate(memberpost);
		
	}

	@Override
	@Transactional
	public int schoolcounter(int sn) {

		return memberMapper.schoolcounter(sn);
	}

	@Override
	@Transactional
	public int postcounter(int sn) {

		return memberMapper.postcounter(sn);
		
	}

	@Override
	@Transactional
	public void refreshfriend(Member sn, int count) {
			
		memberMapper.refreshfriend(sn, count);
		
		System.out.println(sn.getSn()+"번회원 친구수 업데이트 완료. MemberDAO.refreshfriend");

	}
	
	@Override
	@Transactional
	public void changeProfile(int profile,int sn) {
		memberMapper.changeProfile(profile, sn);
	}

	@Override
	@Transactional
	public Member findSnNameProfile(int sn) {
		
		return memberMapper.findSnNameProfile(sn);
		
	}
	
	@Override
	@Transactional
    public List<Member> selectuser(String name) {
    
       return memberMapper.selectuser(name);
       
    }
	
	@Override
	@Transactional
	   public List<Member> likelist(int sn) {
		
	    return memberMapper.likelist(sn);
	      
	 }
	
	@Override
	@Transactional
	public void changeBackProfile(int profile,int sn) {
		memberMapper.changeBackProfile(profile, sn);
	}

	@Override
	@Transactional
	public Member myfriendstate(int sn) {
		
		Member my_sn = memberMapper.findSimple(sn);
		
		if(memberMapper.findfriends(sn).size()!=0) {
			
		my_sn.setFriends(memberMapper.findfriends(sn));
		
		for(Friend friend : my_sn.getFriends()) {
			
			Member friend_sn = new Member();
			
			friend_sn = friend.getFriend_sn();
			
			friend.getFriend_sn().setLogin(loginMapper.friendstate(friend_sn));

		}
		
		}
		
		return my_sn;
	}

}