package com.lec206.acebook.dataservice_member;

import java.util.List;

import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.common_member.MemberPost;
import com.lec206.acebook.common_member.MemberSchool;

public interface IMemberDAO {
	
	//일시이용{
	void save(Member member);
	//void preparesave(Member nMember);}
	
	/*
	void accept(String id); 
	 */
	Member findBySn(int sn);
	Member findSimple(int sn);
	List<Member> selectAll();
	boolean isIn(String id);//중복검사 
	
	//학교정보{
	void schoolsave(MemberSchool memberschool);
	void schoolupdate(MemberSchool memberschool);
	int schoolcounter(int sn);
	
	//학교정보}
	
	//주소정보{
	void postsave(MemberPost memberpost);
	void postupdate(MemberPost memberpost);
	int postcounter(int sn);
	//주소정보}
	
	//친구수조회{
	void refreshfriend(Member sn,int count);
	
	//친구전용 찾기
	Member findSnNameProfile(int sn);
	
	//회원프로필
	void changeProfile(int profile,int sn);
	
	//인물검색ajax
	List<Member> selectuser(String name);
	
	//게시물좋아요누른사람출력
	List<Member> likelist(int sn);
	
	//백프로필변경
	void changeBackProfile(int profile,int sn);
	
	//내친구상태조회
	Member myfriendstate(int sn);
}
