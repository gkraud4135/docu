package com.lec206.acebook.common_friend;

public class Message {

}
