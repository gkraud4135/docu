package com.lec206.acebook.manage_friend;

import com.lec206.acebook.util.BusinessResult;

public interface I친구관리 {
	
	//return : void
	BusinessResult 친구신청(int my_sn, int friend_sn);
	
	//return : void
	BusinessResult 친구수락(int my_sn, int friend_sn);
	
	//return : void
	BusinessResult 친구거절(int my_sn, int friend_sn);
	
	//return : void
	BusinessResult 친구차단(int my_sn, int friend_sn);
	
	//return : void
	BusinessResult 친구삭제(int my_sn, int friend_sn);
	
	//return : List<Friend>
	BusinessResult 받은친구요청(int mysn);
	
	//return : int 테스트코드
	BusinessResult 내친구수(int mysn);

}
