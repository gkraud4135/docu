package com.lec206.acebook.manage_friend;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lec206.acebook.common_friend.Friend;
import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.dataservice_friend.IFriendDAO;
import com.lec206.acebook.util.BusinessResult;
import com.lec206.acebook.util.ERRORCODE;

@Service
public class 친구관리자 implements I친구관리 {

	@Autowired IFriendDAO friendDAO;
	
	@Override
	@Transactional
	public BusinessResult 친구신청(int my_sn, int friend_sn) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부(friendDAO.request, friendDAO.checkrequest)
		
		//상대방과 자신 둘다 신청중이지 않을경우에만 친구신청가능
		if(friendDAO.checkrequest(my_sn, friend_sn) || friendDAO.checkrequest(friend_sn , my_sn)) {
		
		return new BusinessResult(ERRORCODE.신청중,"이미신청중이거나 신청받았습니다.");
		
		}
		
		System.out.println("친구신청이 완료됬어요!");
		
		friendDAO.request(my_sn, friend_sn);
		
		return new BusinessResult();

	}
	
	@Override
	@Transactional
	public BusinessResult 친구수락(int mysn, int friendsn) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부(friendDAO.accept)
		
		friendDAO.accept(mysn, friendsn);
		
		return new BusinessResult();

	}
	
	@Override
	@Transactional
	public BusinessResult 친구거절(int my_sn, int friend_sn) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부(friendDAO.reject)
		
		friendDAO.reject(my_sn, friend_sn);
		
		return new BusinessResult();

	}

	@Override
	@Transactional
	public BusinessResult 친구차단(int my_sn, int friend_sn) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부(friendDAO.block)
		
		friendDAO.block(my_sn, friend_sn);
		
		return new BusinessResult();

	}
	
	@Override
	@Transactional
	public BusinessResult 받은친구요청(int mysn) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부(friendDAO.block)
		
		List<Friend> friends = friendDAO.requests(mysn);
		
		System.out.println(friends.size());
		
		return new BusinessResult(friends);

	}

	@Override
	@Transactional
	public BusinessResult 내친구수(int mysn) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부(friendDAO.friendCounter)
		
		return new BusinessResult(friendDAO.friendCounter(mysn));
		
	}

	@Override
	@Transactional
	public BusinessResult 친구삭제(int my_sn, int friend_sn) {
		
		friendDAO.deleteFriend(my_sn, friend_sn);
		friendDAO.deleteFriend(friend_sn, my_sn);

		return new BusinessResult();
	}

}