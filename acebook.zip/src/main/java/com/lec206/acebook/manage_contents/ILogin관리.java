package com.lec206.acebook.manage_contents;

import com.lec206.acebook.util.BusinessResult;

public interface ILogin관리 {
	
	//retrun : state : ({sn : int},{name : String},{id : String},{state:enum})
	BusinessResult 로그인(String id, String password);
	
	//return : void
	BusinessResult 로그아웃(int sn);
	

}
