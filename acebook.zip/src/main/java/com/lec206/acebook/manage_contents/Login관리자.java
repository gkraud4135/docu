package com.lec206.acebook.manage_contents;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.dataservice_contents.ILoginDAO;
import com.lec206.acebook.dataservice_member.IMemberDAO;
import com.lec206.acebook.util.BusinessResult;
import com.lec206.acebook.util.ERRORCODE;

@Service
public class Login관리자 implements ILogin관리 {

	@Autowired ILoginDAO loginDAO;
	@Autowired IMemberDAO memberDAO;
	
	
	@Override
	@Transactional
	public BusinessResult 로그인(String id, String password) {
		
		//업무
		Login login = null;
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부(loginDAO.login())
		
		HashMap<String, Object> state = loginDAO.login(id, password);
		
		//로그인에 실패했을경우, return 에러코드 존재하지않는회원
		
		if(state==null) {
			
			return new BusinessResult(ERRORCODE.존재하지않는회원, "해당정보가 존재하지 않습니다.");
			
		}
		
		//로그인을 성공하였을경우
		login = new Login();
		login.setSn(memberDAO.findBySn((int)state.get("sn")));
		System.out.println(login.getSn().getSn()+"<-저장된 회원번호");
		//받은 회원번호로 생성된 로그인객체에 회원번호 저장
		//login.setSn();
		
		//----------------------------------------------------------
		//로그인을 처음했을경우 로그인table에 저장 
		//로그인을 처음햇을경우에 상세정보입력창으로 보내줄 예정!
		if(loginDAO.counter(login.getSn().getSn())==0) {
		
		System.out.println(login.getSn().getSn()+"<-님은 첫로그인 대상자입니다. 상세정보 입력페이지로 이동");
	
		loginDAO.save(login);
		
		loginDAO.loginstate(login);

		return new BusinessResult(state,ERRORCODE.첫로그인,"첫로그인대상자");
			
		}
		//--------------------------------------------------------첫로그인
		
		//로그인 1회 이후부터는 로그인정보만 갱신됨
		System.out.println();
		try {
			
			loginDAO.loginstate(login);
			
			} catch(Exception e) { 

			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		
		return new BusinessResult(state);
	}
	
	@Override
	@Transactional
	public BusinessResult 로그아웃(int sn) {
		
		//업무
		Login login = new Login();
		//1-1업무규칙검사
		
		login = loginDAO.findBySn(sn);
		
		//1-2업무실행

		//DB이용여부(loginDAO.logout)
		
		loginDAO.logoutstate(login);
		
		System.out.println("login관리자.logout 정상작동완료!");

		return new BusinessResult();

	}


}