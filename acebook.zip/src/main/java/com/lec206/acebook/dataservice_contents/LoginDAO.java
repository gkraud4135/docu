package com.lec206.acebook.dataservice_contents;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.dataservice_member.IMemberMapper;

@Repository
public class LoginDAO implements ILoginDAO {
	
	@Autowired ILoginMapper loginMapper;

	@Override
	@Transactional
	public HashMap<String, Object> login(String id, String password) {
		
		return loginMapper.login(id, password);
	}

	@Override
	@Transactional
	public int counter(int sn) {
		
		return loginMapper.counter(sn);
		
	}
	
	@Override
	@Transactional
	public void save(Login login) {
		
		loginMapper.save(login);

	}

	@Override
	@Transactional
	public Login findBySn(int sn) {
		
		return loginMapper.findBySn(sn);
		
	}

	@Override
	@Transactional
	public void loginstate(Login login) {

		loginMapper.loginstate(login);
		
	}

	@Override
	@Transactional
	public void logoutstate(Login login) {
		
		loginMapper.logoutstate(login);
		
	}

}