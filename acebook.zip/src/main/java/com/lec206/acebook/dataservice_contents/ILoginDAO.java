package com.lec206.acebook.dataservice_contents;

import java.util.HashMap;

import com.lec206.acebook.common_member.Login;

public interface ILoginDAO {
	
	HashMap<String,Object> login(String id, String password);
	
	int counter(int sn);
	
	void save(Login login);
	
	Login findBySn(int sn);
	
	void loginstate(Login login);
	
	void logoutstate(Login login);

}
