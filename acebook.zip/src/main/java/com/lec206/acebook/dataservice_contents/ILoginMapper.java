package com.lec206.acebook.dataservice_contents;

import java.util.HashMap;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.common_member.Member;

@Mapper
public interface ILoginMapper {
	
	@Select("select sn,name,state,id from member where id=#{id} and password=#{password} and state='회원'")
	HashMap<String,Object> login(@Param("id")String id, @Param("password")String password);//로그인
	
	@Select("Select if(count(*)=1,1,0) from state where sn=#{sn}")
	int counter(@Param("sn") int sn);
	
	@Insert("Insert into state(sn) values (#{sn.sn})")
	void save(Login login);
	
	   @Select("Select * from state where sn=#{sn}")
	   @Results(value= {
	         @Result(property = "sn.sn", column="sn"),
	         @Result(property = "state", column="state"),
	         @Result(property = "viewTime", column="viewTime"),
	         @Result(property = "lastViewTime", column="lastViewTime"),
	         @Result(property = "loginTime", column="loginTime"),
	         @Result(property = "logoutTIme", column="logoutTIme")})
	   Login findBySn(@Param("sn") int sn);

	
		@Update("update state set state = '접속중', loginTime = current_timestamp() where sn=#{sn.sn};")
		void loginstate(Login login);
		
		@Update("update state set state = '로그오프', logoutTime = current_timestamp() where sn=#{sn.sn};")
		void logoutstate(Login login);
		
		//학명이 추가코드
		@Update("update state set lastviewtime = viewtime where sn=#{sn}")
		void viewtimeupdate(@Param("sn") int sn);
		
		@Update("update state set viewtime=current_timestamp() where sn=#{sn}")
		void lasttimeupdate(@Param("sn") int sn);
		
		//로그인상태 출력
		@Select("select * from state where sn=#{friend_sn.sn}")
		Login friendstate(@Param("friend_sn")Member friend_sn);

}