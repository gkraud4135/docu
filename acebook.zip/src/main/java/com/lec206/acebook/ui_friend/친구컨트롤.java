package com.lec206.acebook.ui_friend;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import org.springframework.web.servlet.ModelAndView;

import com.lec206.acebook.common_friend.Friend;
import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.manage_friend.I친구관리;
import com.lec206.acebook.manage_member.I회원관리;
import com.lec206.acebook.util.BusinessResult;
import com.lec206.acebook.util.ERRORCODE;

//친구관련 기능들은 Ajax로 처리하거나 요청에 따라 바로 응답하기떄문에 RestController가 적절하다고 생각됨.

@Controller
public class 친구컨트롤 {
	
	@Autowired I친구관리 친구관리자;
	@Autowired I회원관리 회원관리자;
	
	@RequestMapping("friend")
	public String friend() {
		return "friend/친구"; 
	}

	@ResponseBody
	@RequestMapping("request/{sn}")
	public String test(@PathVariable int sn,HttpSession session) {
				
		//1.요청페이지(.jsp)
	//	ModelAndView mv = new ModelAndView();
		//2.업무
		int 친구신청자번호=(int)session.getAttribute("sn");
		System.out.println("친구신청자번호:"+친구신청자번호);
		System.out.println("신청받은회원번호:"+sn);
			BusinessResult br = 친구관리자.친구신청(친구신청자번호,sn);//  내번호2  personpage번호1			
	//		BusinessResult br = 친구관리자.친구수락(1, 2);// 받은사람번호 신청한사람번호			
	//		BusinessResult br = 친구관리자.친구차단(2,1);//
			//비정상코드입력시
			//if(br.getCode()!=ERRORCODE.NOMAL) {}
			System.out.println("RequestMapping");
								
		//3.경로지정
		
		
		//mv.addObject("key", value);
		//System.out.println(mv.getViewName()+"으로 이동중");
		
		return " ";
	
	}
	@RequestMapping(value="requests",method= {RequestMethod.POST},produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String test(HttpSession session) {
				
		//2.업무
			int 내회원번호=(int)session.getAttribute("sn");
			BusinessResult br=친구관리자.받은친구요청(내회원번호);
			//비정상코드입력시
			//if(br.getCode()!=ERRORCODE.NOMAL) {}
		String html="";
		html+="<h2>받은친구요청</h2>";
		List<Friend> friends = (List<Friend>)br.getValue();
		if(friends!=null) {
		for(Friend friend : friends) {
				html+="<ul>";				
				html+="<img src=/board/attach/"+friend.getMy_sn().getProfile()+"height=\"70\" width=\"70\"/>";
				html+=friend.getMy_sn().getSn();				
				html+= "<a href=personpage/"+friend.getMy_sn().getSn()+">";				
				html+=friend.getMy_sn().getName();							
				html+="</a>";				
				html+="</li>";
				html+="</ul>";
		
			//	System.out.print("친구번호:"+friend.getMy_sn().getSn());	
			//	System.out.println("친구신청한이름:"+friend.getMy_sn().getName());
		}
		}else {
			html+="<h3>받은친구요청이없습니다.</h3>";
		}
		
		return html;
	
	}
	@ResponseBody
	@GetMapping("accept/{sn}")
	public String 친구수락(@PathVariable int sn,HttpSession session) {
				
		//1.요청페이지(.jsp)
	//	ModelAndView mv = new ModelAndView();
		//2.업무
		int 내번호 = (int)session.getAttribute("sn");
		
		BusinessResult br = 친구관리자.친구수락(내번호,sn);
		//BusinessResult br = 친구관리자.친구수락(2, 1);
		//			br = 친구관리자.친구수락(69, 1);
		
								
		//3.경로지정
		
		
		//mv.addObject("key", value);
		//System.out.println(mv.getViewName()+"으로 이동중");
		
		return " ";
	
	}
	
	@ResponseBody
	@RequestMapping(value="myfriends",method= {RequestMethod.POST},produces="text/plain;charset=UTF-8")
	public String 내친구목록(HttpSession session) {
				
		//2.업무
			int 내번호=(int)session.getAttribute("sn");
			BusinessResult br = 회원관리자.회원정보조회(내번호);
			
			Member member = (Member)br.getValue();
			String html="";
			html+="<h2>모든친구목록</h2>";
			if(member.getFriends()!=null) {
				for(Friend friend : member.getFriends()) {
					html+="<ul>";				
					html+=friend.getFriend_sn().getSn();				
					html+="<img src=/board/attach/"+friend.getFriend_sn().getProfile()+"height=\"70\" width=\"70\"/>";
					html+= "<a href=personpage/"+friend.getFriend_sn().getSn()+">";
					html+=friend.getFriend_sn().getName();						
					html+="</a>";
					html+="</li>";
					html+="</ul>";
					
					System.out.print(friend.getFriend_sn().getSn()+"<-회원번호 ");
					System.out.println(friend.getFriend_sn().getName()+"<-님은 친구입니다");
					
				}
			}else {
				html+="<h3>친구가없습니다.</h3>";
			}
						
		return html;
	
	}
	
	@GetMapping("friendstate")
	public String 친구들출력() {
		
		return "friend/내친구들"; 
	}
	
	
	
	@ResponseBody
	@RequestMapping(value="friendstate",method= {RequestMethod.GET, RequestMethod.POST},produces="text/plain;charset=UTF-8")
	public String 내친구상태(HttpSession session) {
				
		//2.업무
		
			String html="";
			html+="<h2>내친구상태</h2>";
			
			int 로그인번호 = (int)session.getAttribute("sn");

		
			BusinessResult br = 회원관리자.친구상태출력(로그인번호);
			
			if(br.getCode()!=ERRORCODE.NORMAL) {
				
				if(br.getCode()==ERRORCODE.존재하지않는회원) {
					
					html+="<h2>친구가 없어요!</h2>";
					
					System.out.println("friendstate이동중");
					return html;
					
				}
			}
			
			Member member = (Member)br.getValue();

				for(Friend friend : member.getFriends()) {
					html+="<ul>";				
					html+=friend.getFriend_sn().getLogin().getState();
					html+="<img src=/board/attach/"+friend.getFriend_sn().getProfile()+"height=\"70\" width=\"70\"/>";
					html+=friend.getFriend_sn().getName();				
					//html+= "<a href=personpage/"+friend.getFriend_sn().getSn()+">"; 1:1 대화열기 가능할듯		
					html+="</a>";
					html+="</li>";
					html+="</ul>";
				}

		return html;
	
	}
	
	@GetMapping("testfriend")
	public String get친구테스트() {
				
		//1.요청페이지(.jsp)
		ModelAndView mv = new ModelAndView();
		
		//2.업무
		BusinessResult br = 회원관리자.전체회원출력();
		List<Member> members = (List<Member>)br.getValue();
		//친구관계 더미데이터
		//1번 회원부터 5번회원까지 친구더미데이터 생성 준비
		for(int j = 3; j<4; j++) {
			List<Integer> counter = new ArrayList<Integer>();
			System.out.println(j+" 번 회원 친구 추가중 현제 카운터 크기는? "+counter.size());
			br = 회원관리자.회원정보조회(j);
			Member member = (Member)br.getValue();
			int my_sn = j;
			
			
			if(member.getFriends()!=null) {
				
				counter.add(my_sn);
				
				for(Friend friend : member.getFriends()) {
					
					counter.add(friend.getFriend_sn().getSn());
					
					System.out.println("counter가 이미 친구인"+friend.getFriend_sn().getSn()+"를 저장했어요!");
					
				}
				
				}
				System.out.println(counter.size()+"현제 카운터의 크기입니다!");
			
		for(int i=0; i<15; i++) {
			
			int friend_sn;
			Integer 확인번호=0;
			Integer	랜덤회원=0;
			int counting=0;
			
			while(true) {
				
				System.out.println("다시 시작!");
				
				랜덤회원 = (int)((Math.random()*members.size())+1);
				
				확인번호 = 랜덤회원;
				
				for(Integer count : counter) {

					if(count==확인번호) {
						System.out.println(확인번호+"랜덤번호");
						counting += 1;
					
					}
					
					if((counter.indexOf(count)+1)==counter.size() && counting==0) {
						
						System.out.println("증복되지 않은 회원을 찾앗어요!");
						counter.add(확인번호);

						break;

					}

					}
				
					friend_sn = 확인번호;
					System.out.println(확인번호+"번 회원은 친구신청을 안했어요!");
		            br = 친구관리자.친구신청(my_sn, friend_sn);
		            br = 친구관리자.친구수락(friend_sn, my_sn);

		               System.out.println(확인번호+"를 counter에 추가하고 while문을 종료합니다!");
		               System.out.println(counter.size()+"현제 카운터의 크기입니다.");
		               break;
				}

			}
		}

			

		return " ";
	
	}

	}
	