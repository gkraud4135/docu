package com.lec206.acebook.dataservice_friend;

import java.util.List;

import com.lec206.acebook.common_friend.Friend;
import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.common_member.Member;

public interface IFriendDAO {
	
	//친구신청
	void request(int mysn,int friendsn);
	
	//친구신청을 해놧는지 확인하는 메서드
	boolean checkrequest(int mysn, int friendsn);
	
	//친구신청목록확인
	List<Friend> requests(int mysn);
	
	//친구신청수락
	void accept(int mysn,int friendsn);
	
	//친구신청거절
	void reject(int mysn, int friendsn);
	
	//상태 > 차단
	void block(int my_sn, int friend_sn);
	
	//친구삭제
	void deleteFriend(int mysn, int friendsn);
	
	//나의친구목록저장용
	List<Member> selectFriends(int sn);
	
	//나의친구수저장용
	int friendCounter(int mysn);

}