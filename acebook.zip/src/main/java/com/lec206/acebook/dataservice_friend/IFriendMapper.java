package com.lec206.acebook.dataservice_friend;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.lec206.acebook.common_friend.Friend;
import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.common_member.Member;

@Mapper
public interface IFriendMapper {

	//친구신청관련{
	@Insert("insert into friend(my_sn, friend_sn, state) values(#{my_sn.sn},#{friend_sn.sn},'신청중')")
	void request(@Param("my_sn")Member my_sn,@Param("friend_sn")Member friend_sn);
	
	//친구신청중인것 확인
	@Select("select if(count(*)=1,1,0) from friend where my_sn=#{my_sn.sn} and friend_sn=#{friend_sn.sn} and state='신청중'")
	boolean checkrequest(@Param("my_sn")Member my_sn, @Param("friend_sn")Member friend_sn);
	
	//받은 친구신청 확인하기
	@Select("select my_sn,state from friend where state='신청중' and friend_sn=#{my_sn.sn}")
	@Results(value = {
			@Result(property = "state", column = "state"),
			@Result(property = "my_sn", column = "my_sn", one=@One(select = "com.lec206.acebook.dataservice_member.IMemberMapper.findSnNameProfile"))})
	List<Friend> requests(@Param("my_sn")Member my_sn);
	
	//친구신청 수락할경우{
	@Insert("insert into friend(my_sn, friend_sn, state) values(#{my_sn.sn},#{friend_sn.sn},'친구')")
	void accept(@Param("my_sn")Member my_sn,@Param("friend_sn")Member friend_sn);

	//친구가 됫을경우 상대방입장에서 자신이 friend_sn이기 때문에 반대로 update하는 sql문하나 필요함
	//beFriend 친구가되다라는 의미에서 이름을 지엇음.
	@Update("update friend set state = '친구' where my_sn=#{friend_sn.sn} and friend_sn=#{my_sn.sn};")
	void beFriend(@Param("my_sn")Member my_sn,@Param("friend_sn")Member friend_sn);
	
	//친구신청 수락할경우}
	
	//친구신청 거절
	@Delete("delete from friend where my_sn = #{friend_sn.sn} and friend_sn=#{my_sn.sn}")
	void reject(@Param("my_sn")Member my_sn,@Param("friend_sn")Member friend_sn);
	
	//친구신청관련}
	
	//차단
	@Update("update friend set state = '차단' where my_sn=#{my_sn.sn} and friend_sn=#{friend_sn.sn};")
	void block(@Param("my_sn")int my_sn,@Param("friend_sn") int friend_sn);
	
	//친구목록 출력 수정요망
	//신청중인 사람이 잇을수도 잇으므로 and연산자로 나의 번호로 등록된 열들중 상태가 친구인 목록출력
	@Select("select friend_sn from friend where my_sn=#{my_sn} and state = '친구'")
	List<Member> selectFriends(@Param("my_sn")int my_sn);

	//친구수 출력
	//위와 동일함
	@Select("select count(*) from friend where my_sn=#{mysn} and state='친구'")
	int friendCounter(@Param("mysn")int mysn);
	
	//친구삭제 [수정여부있음]
	@Delete("Delete from friend where my_sn=#{my_sn.sn} and friend_sn = #{friend_sn.sn}")
	void deleteFriend(@Param("my_sn")Member my_sn, @Param("friend_sn")Member friend_sn);
	/*
	//내친구들의상태 출력
	@Select("select * from state left join friend on state.sn = friend.friend_sn where friend.my_sn=#{my_sn} order by friend_sn")
	List<Login> friendstates(@Param("my_sn")int my_sn);
	*/

}