package com.lec206.acebook.dataservice_friend;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lec206.acebook.common_friend.Friend;
import com.lec206.acebook.common_member.Login;
import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.dataservice_member.IMemberMapper;

@Repository
public class FriendDAO implements IFriendDAO {
	
	@Autowired IFriendMapper friendMapper;
	@Autowired IMemberMapper memberMapper;
	
	//친구신청중인지 확인
	@Override
	@Transactional
	public boolean checkrequest(int mysn, int friendsn) {
		
		Member my_sn = memberMapper.findSimple(mysn);
		Member friend_sn = memberMapper.findSimple(friendsn);

		return friendMapper.checkrequest(my_sn, friend_sn);
		
	}
	
	//친구신청하기
	@Override
	@Transactional
	public void request(int mysn,int friendsn) {
		
		Member my_sn = memberMapper.findSimple(mysn);
		Member friend_sn = memberMapper.findSimple(friendsn);
		//신청할경우 신청중으로 나와야되어서 insert문 state = 신청중으로 입력됨
		friendMapper.request(my_sn, friend_sn);
		
	}

	//친구신청 받은 목록
	@Override
	@Transactional
	public List<Friend> requests(int mysn) {
		
		Member my_sn = memberMapper.findSimple(mysn);

		return friendMapper.requests(my_sn);
		
	}


	//친구신청수락
	@Override
	@Transactional
	public void accept(int mysn, int friendsn) {

		int count = 0;

		Member my_sn = memberMapper.findSimple(mysn);
		Member friend_sn = memberMapper.findSimple(friendsn);
		
		//요청수락할경우 insert문으로 친구로 내친구목록도 추가해서 저장
		friendMapper.accept(my_sn, friend_sn);
		
		//친구수가 변동되엇기 떄문에 친구수 업데이트{
		count = friendMapper.friendCounter(mysn);
		memberMapper.refreshfriend(my_sn, count);
		//나의 친구수 업데이트 완료}
		
		//요청을 수락했기 때문에 update문으로 신청한 친구를 신청중에서 친구로 변경
		friendMapper.beFriend(my_sn, friend_sn);
		count = friendMapper.friendCounter(friendsn);
		//상대가 요청을 수락했으므로 요청자의 친구수도 변동이 되기때문에 친구수 업데이트{
		
		memberMapper.refreshfriend(friend_sn, count);

		
		//신청한 사람의 친구수 업데이트 완료}
		
		

	}

	@Override
	@Transactional
	public void reject(int mysn, int friendsn) {
		
		Member my_sn = memberMapper.findSimple(mysn);
		Member friend_sn = memberMapper.findSimple(friendsn);
			
		friendMapper.reject(my_sn, friend_sn);
		
	}



	@Override
	@Transactional
	public void block(int my_sn, int friend_sn) {
		
		friendMapper.block(my_sn, friend_sn);
		
	}



	@Override
	@Transactional
	public List<Member> selectFriends(int sn) {
		
		return friendMapper.selectFriends(sn);
		
	}


	@Override
	@Transactional
	public int friendCounter(int mysn) {

		return friendMapper.friendCounter(mysn);
		
	}

	@Override
	@Transactional
	public void deleteFriend(int mysn, int friendsn) {
		
		int count = 0;

		
		Member my_sn = memberMapper.findSimple(mysn);
		Member friend_sn = memberMapper.findSimple(friendsn);
		
		friendMapper.deleteFriend(my_sn, friend_sn);
		count = friendMapper.friendCounter(mysn);
		memberMapper.refreshfriend(my_sn, count);
		
	}
	
}