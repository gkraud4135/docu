package com.lec206.acebook.dataservice_friend;

import java.util.List;

import com.lec206.acebook.common_friend.Message;

public class MesseageDAO implements IMesseageDAO {

	@Override
	public void save(Message nMessage) {

	}

	@Override
	public Message findBySn(int sn) {
		
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Message> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
