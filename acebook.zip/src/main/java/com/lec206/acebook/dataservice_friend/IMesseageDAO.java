package com.lec206.acebook.dataservice_friend;

import java.util.List;

import com.lec206.acebook.common_friend.Message;

public interface IMesseageDAO {

	void save(Message nMessage);
	Message findBySn(int sn);
	List<Message> selectAll();
	
}
