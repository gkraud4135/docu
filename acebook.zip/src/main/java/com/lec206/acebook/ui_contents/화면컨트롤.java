package com.lec206.acebook.ui_contents;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.manage_contents.ILogin관리;
import com.lec206.acebook.manage_member.I회원관리;
import com.lec206.acebook.util.BusinessResult;
import com.lec206.acebook.util.ERRORCODE;
import com.lec206.acebook.util.로그인상태;

@Controller
public class 화면컨트롤 {
	
	@Autowired ILogin관리 login관리자;
	@Autowired I회원관리 회원관리자;

	@GetMapping("main")
	public String getMain() {
				
			//1.요청페이지(acebook.jsp)
			
			
			//2.업무
			
			//3.경로지정
			System.out.println("main으로 이동중");
			
		return "acebook";

	}

	//메인에서 post로 요청(login요청)
	@PostMapping("main")
	public ModelAndView postMain(String id, String password, HttpSession session) {
				
			//1.요청페이지(acebook.jsp)
			ModelAndView mv = new ModelAndView();
		
			//2.업무
	
			BusinessResult br =  login관리자.로그인(id, password);
			
			//비정상코드입력시
			if(br.getCode()!=ERRORCODE.NORMAL) {
			if(br.getCode()==ERRORCODE.존재하지않는회원) {
				
				mv.setViewName("acebook");
				mv.addObject("error",br.getCode());
				mv.addObject("msg", br.getMsg());
				
				return mv;
			}
			
			if(br.getCode()==ERRORCODE.첫로그인) {
			HashMap<String, Object> state = (HashMap<String, Object>)br.getValue();
			session.setAttribute("sn", state.get("sn"));
			session.setAttribute("name", state.get("name"));
			session.setAttribute("id", state.get("id"));
			mv.setViewName("member/학교등록");
			return mv;
			}
		
				 
			}
			
			HashMap<String, Object> state = (HashMap<String, Object>)br.getValue();
			
			session.setAttribute("sn", state.get("sn"));
			session.setAttribute("name", state.get("name"));
			session.setAttribute("id", state.get("id"));
			
			br = 회원관리자.회원정보조회((int)state.get("sn"));
			Member member = (Member)br.getValue();

			mv.addObject("member", member);
			mv.addObject("test", true);
		
			//3.경로지정
				mv.setViewName("acebook");
				System.out.println("main으로 이동중");
			
		return mv;

		}
	
	@RequestMapping("logout")
	public ModelAndView 로그아웃(HttpSession session) {
		
		//1.요청페이지(acebook.jsp)
		ModelAndView mv = new ModelAndView();
		
		//2.업무(session에서 로그인정보 삭제)
		BusinessResult br = login관리자.로그아웃((int)session.getAttribute("sn"));
		
		if(session!=null) {
  			
			//세션이 살아잇을경우 세션을 무효화시킴? 제거시킴?
	     	session.invalidate();
	      			
	      }
		
		//3.경로지정
			mv.setViewName("redirect:/main");
			System.out.println("로그아웃완료");
		
	return mv;

}
	
	@GetMapping("logintest")
	public String 로그인test() {
		
		BusinessResult br = 회원관리자.전체회원출력();
		
		List<Member> 회원들 =  (List<Member>)br.getValue();
		
			for(Member member : 회원들) {
				
			br = login관리자.로그인(member.getId(), member.getPassword());
			
			}
		
				
		return "";

		}
	
	@GetMapping("logouttest")
	public String 로그아웃test() {
		BusinessResult br = 회원관리자.전체회원출력();
		
		List<Member> 회원들 =  (List<Member>)br.getValue();
		
			for(Member member : 회원들) {
				
			br = login관리자.로그아웃(member.getSn());
			
			}
		
				
		return "";

		}

}