package com.lec206.acebook.manage_member;

import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.common_member.MemberPost;
import com.lec206.acebook.common_member.MemberSchool;
import com.lec206.acebook.util.BusinessResult;

public interface I회원관리 {
	
	//return : void
	BusinessResult 회원등록준비(Member member);

	//retrun : member.all(중요정보 제외)
	BusinessResult 회원정보조회(int sn);
	
	//return : boolean
	BusinessResult 중복검사(String id);
	
	//return : void
	BusinessResult 학교등록(MemberSchool memberschool);
	
	//return : void
	BusinessResult 주소등록(MemberPost memberpost);
	
	//return : List<Member>
	BusinessResult 유저출력(String name);
	
	//return : List<Member> member
	BusinessResult 좋아요누른사람(int sn);
	
	//return : List<Member> member
	BusinessResult 전체회원출력();
	
	//return : Member
	BusinessResult 친구상태출력(int sn);

}
