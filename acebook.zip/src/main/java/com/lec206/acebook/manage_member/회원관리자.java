package com.lec206.acebook.manage_member;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lec206.acebook.common_friend.Friend;
import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.common_member.MemberPost;
import com.lec206.acebook.common_member.MemberSchool;
import com.lec206.acebook.dataservice_member.IMemberDAO;
import com.lec206.acebook.util.BusinessResult;
import com.lec206.acebook.util.ERRORCODE;

@Service
public class 회원관리자 implements I회원관리 {

	@Autowired IMemberDAO memberDAO;
	
	@Override
	@Transactional
	public BusinessResult 회원등록준비(Member member) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행

		//DB이용여부(memberDAO.save())
		
		memberDAO.save(member);
		
		return new BusinessResult();

	}

	@Override
	@Transactional
	public BusinessResult 회원정보조회(int sn) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행
		
		//DB이용여부(memberDAO.findByNo);
		
		Member member = memberDAO.findSimple(sn);
		
		return new BusinessResult(member);

	}

	@Override
	@Transactional
	public BusinessResult 중복검사(String id) {
	      
	      boolean 사용가능; 

	      //업무

	      //1-1업무규칙검사
	      
	      if(id!=null) {
	      	
	    	  if(id.length()!=id.replaceAll(" ", "").length()) {
	      
	    		  return new BusinessResult(ERRORCODE.아이디공백, "아이디에 공백을 넣을수 없어요");
	    		  
	    	  }
	    	  
			if(!id.matches("^[A-z|0-9]([A-z|0-9]*)(@)([A-z]*)(\\.)([A-z]*)$")) {
				
				return new BusinessResult(ERRORCODE.이메일형식,"아이디가 이메일 형식이 아니에요!");
				
			}

	      }
	      
	      //1-2업무실행

	      //DB이용여부(memberDAO.isin())
	      
	      사용가능 = memberDAO.isIn(id);
	      
	      return new BusinessResult(사용가능);
	   }

	@Override
	@Transactional
	public BusinessResult 학교등록(MemberSchool memberschool) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행
		
		//DB이용여부(memberDAO.schoolsave, memberDAO.schoolupdate);
		
		//db에 저장된 학교정보가 없을경우는 save를 함.
		
		if(memberDAO.schoolcounter(memberschool.getSn().getSn())==0) {
			
			System.out.println("등록된 학교정보가 없어요!");
			
			memberDAO.schoolsave(memberschool);
			
			return new BusinessResult();
			
			}
		
		//db에 저장된 학교정보가 있을경우에는 update를 함.
		
		memberDAO.schoolupdate(memberschool);

		return new BusinessResult();
		
	}
	
	@Override
	@Transactional
	public BusinessResult 주소등록(MemberPost memberpost) {
		
		//업무
		
		//1-1업무규칙검사
	
		//1-2업무실행
		
		//DB이용여부(memberDAO.postsave, memberDAO.postupdate);
		
		//회원에게 등록된 주소가 없을경우 저장
		if(memberDAO.postcounter(memberpost.getSn().getSn())==0) {
			
			memberDAO.postsave(memberpost);
			
			return new BusinessResult();
			
			}
		
		//회원에게 등록된 주소가 잇을경우 업데이트를 함
		
		memberDAO.postupdate(memberpost);
		
	    return new BusinessResult();
	    
	   }
	
	@Override
	@Transactional
	public BusinessResult 유저출력(String name) {
	      
	      //업무
	      
	      //1-1업무규칙검사
	   
	      //1-2업무실행
	      
	      //DB이용여부(memberDAO.selectuser);
	      List<Member> member = memberDAO.selectuser(name);
	      
	      return  new BusinessResult(member);

	       }
	
	   @Override
	   @Transactional
	   public BusinessResult 좋아요누른사람(int sn) {
	      
	      //업무
	      
	      //1-1업무규칙검사
	   
	      //1-2업무실행
	      
	      //DB이용여부(memberDAO.selectall);
	      List<Member> member = memberDAO.likelist(sn);
	      return  new BusinessResult(member);
	      
	         
	         }

	@Override
	@Transactional
	public BusinessResult 전체회원출력() {
		
	      //업무
	      
	      //1-1업무규칙검사
	   
	      //1-2업무실행
	      
	      //DB이용여부(memberDAO.selectall);
		List<Member> members = memberDAO.selectAll();
		
		return new BusinessResult(members);
	}

	@Override
	@Transactional
	public BusinessResult 친구상태출력(int sn) {
		
		 //업무
	      
	      //1-1업무규칙검사
	   
	      //1-2업무실행
	      
	      //DB이용여부(memberDAO.myfriendstate);
		
		Member member = memberDAO.myfriendstate(sn);
		
		if(member.getFriends().size()==0) {
			
			return new BusinessResult(ERRORCODE.존재하지않는회원,"친구가 없어요");
			
		}
		
		return new BusinessResult(member);
	}        

}