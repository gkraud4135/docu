package com.lec206.acebook.env;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MyCharsetEncodingFilter implements Filter {

	//UTF-8 필터
    /**
     * Default constructor. 
     */
    public MyCharsetEncodingFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	//doFilter : 요청이 들어올때마다 실행
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		request.setCharacterEncoding("UTF-8");
		//요청처리전
		chain.doFilter(request, response);
		//요청처리후에 추가적으로 필터링해줘야할게 잇다면 chain아래에 작성
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
