package com.lec206.acebook.env;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoginInterceptor extends HandlerInterceptorAdapter {
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
				//preHandle : 요청 -> 컨트롤로 가는 사이에 유효성검사를 함.(컨트롤 진입전)
				//posthandle : 컨트롤러 다음에 
				//afterComplate : 뷰요청을 처리한다음에
		
		//request객체로 부터 session이 등록된경우에만 session을 얻는다.
		HttpSession session = request.getSession(false);
		
		
		
		boolean 로그인 = false;
		
		if(session!=null && session.getAttribute("no")!=null) { // session이 존재하면서, session에 로그인한 회원번호가 존재할경우.
			
			로그인 = true;
			
		}
		
		//로그인이 false일경우(비로그인) : session이 없거나 저장된 회원번호가 존재하지 않을경우 아래의 코드를 실행.
		if(!로그인) {
			
			/* forward로 하고싶을경우.
			request.setAttribute("msg", "loginerror");
			RequestDispatcher rd = request.getRequestDispatcher("/login");
	        rd.forward(request, response);*/
			
			/* redirect로 정보를 보내주고싶을경우에는 session에 넣어서 보내주면 될까? */
			response.sendRedirect("/login");
			
	        return false;
	        
		}
		
		return true;
	}

}
