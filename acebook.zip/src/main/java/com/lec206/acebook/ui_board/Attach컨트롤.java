package com.lec206.acebook.ui_board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lec206.acebook.manage_board.I파일관리;


@Controller
public class Attach컨트롤 {
	@Autowired I파일관리 파일관리자;
	
	@RequestMapping("board/attach/{a_no}")
	public void fileDown(@PathVariable("a_no")int 첨부번호,HttpSession session,HttpServletRequest req, HttpServletResponse rep) {
			//1.요청페이지(게시물등록.jsp)
			//2.업무 
			
			파일관리자.사진출력(첨부번호, req, rep);
			// 사진출력 컨트롤 void
			// 첨부번호 = 0 noimage출력, !=0 : 그번호 게시물의 사진출력
	}
	

}
	

