package com.lec206.acebook.dataservice_board;

import java.util.List;

import com.lec206.acebook.common_board.Attach;
import com.lec206.acebook.common_board.Board;
import com.lec206.acebook.common_board.BoardLike;
import com.lec206.acebook.common_board.Comment;

public interface IBoardDAO {
	
	int save(Board nBoard);
	Attach findBySn(int sn);
	int findattachsn(int sn);
	List<Board> selectAll();
	List<Board> myboard(int sn,int size);
	List<Attach> load(int boardsn);
	List<BoardLike> boardlike(int sn);
	int likes(int no);
	void onoffLike(int bno, int mno,int no);
	int likeis(int bno, int mno);
	List<Comment> findCommentBySn(int sn,int size);
	int comments(int sn);
	void savecomment(Comment comment);
	Comment findComment(int sn);
	void deletecomment(int sn);
	List<Board> mainboard(int sn,int size);
	void viewtimeupdate(int sn);
	int checknewboard(int sn);
	int numberofboard(int sn);
	Attach Advertising();
	void deleteboard(int sn);
	Board findboard(int sn);
	void deleteAttach(int sn);
	void modifyboard(Board board);
	void reportboard(int sn);
	int getsharingsn(int sn);
	void deletesharing(int sn);
}

