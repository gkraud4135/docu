package com.lec206.acebook.dataservice_board;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

import com.lec206.acebook.common_board.Attach;
import com.lec206.acebook.common_board.Board;
import com.lec206.acebook.common_board.BoardLike;
import com.lec206.acebook.common_board.Comment;

@Mapper
public interface IBoardMapper {

	//게시물저장
	@Insert("insert into board(contents,writer,state)values(#{contents},#{writer.sn},#{state})")
	@SelectKey(statement="select last_insert_id()", keyProperty="sn", before=false, resultType=int.class)
	void save(Board board);
	
	//자신의 게시물 출력[자기게시물페이지]
	@Select("select * from board where writer=#{writer.sn}")
	@Results(value = {
			@Result(property = "sn", column = "sn"),
			@Result(property = "contents", column = "contents"),
			@Result(property = "wdate", column = "wdate"),
			@Result(property = "writer", column = "writer", one=@One(select = "com.lec206.acebook.dataservice_member.IMemberMapper.findSimple")),
			@Result(property = "attachs", javaType = List.class, column = "sn",many=@Many(select = "com.lec206.acebook.dataservice_board."+"IAttachMapper.load")) })
	Board findBySn(int sn);
		
	//전체공개인 게시물들을 출력
	@Select("select * from board where state='전체' order by rand() limit 3")
	@Results(value = {
			@Result(property = "sn", column = "sn"),
			@Result(property = "contents", column = "contents"),
			@Result(property = "wdate", column = "wdate"),
			@Result(property = "state", column = "state"),
			@Result(property = "writer", column = "writer", one=@One(select = "com.lec206.acebook.dataservice_member.IMemberMapper.findSimple")), 
	})
	List<Board> selectAll();
	
	//내게시물가져오기
	@Select("select * from board where writer=#{sn} order by wdate desc limit #{size}, 3")
	@Results(value = {
			@Result(property = "sn", column = "sn"),
			@Result(property = "contents", column = "contents"),
			@Result(property = "wdate", column = "wdate"),
			@Result(property = "state", column = "state"),
			@Result(property = "writer", column = "writer", one=@One(select = "com.lec206.acebook.dataservice_member.IMemberMapper.findSimple")), 
			})
	List<Board> myboard(@Param("sn")int sn,@Param("size")int size);
	
	//전체게시물 조건: 친구.친구번호=나, 친구.친구, 게시물.전체,게시물.친구, 시간역순 3개
	@Select("select *from board LEFT JOIN friend ON board.writer = friend.my_sn join state on friend.friend_sn=state.sn where friend.friend_sn=${sn} and (board.state='전체' or board.state='친구') and wdate<viewtime  and wdate>lastviewtime order by board.sn desc limit #{size}, 3")
	@Results(value = {
			@Result(property = "sn", column = "sn"),
			@Result(property = "contents", column = "contents"),
			@Result(property = "wdate", column = "wdate"),
			@Result(property = "state", column = "state"),
			@Result(property = "writer", column = "writer", one=@One(select = "com.lec206.acebook.dataservice_member.IMemberMapper.findSimple")), 
	})
	List<Board> mainboard(@Param("sn")int sn,@Param("size")int size);

	@Select("select * from boardlike where board_sn=#{sn}")
	@Results(value = {
			@Result(property = "like", column = "like"),
			@Result(property = "report", column = "report"),
			@Result(property = "writer.sn", column = "writer"),
			@Result(property = "board.sn", column = "board_sn"),
			})
	List<BoardLike> boardlike(@Param("sn")int sn);
	
	@Select("select count(*) from boardlike where board_sn=#{no}")
	int likes(@Param("no")int no); //게시물당 좋아요 갯수
	
	@Insert("insert into boardlike(board_sn,writer,boardlike.like)values(${bno},${mno},1)")
	void onlike(@Param("bno")int bno,@Param("mno")int mno); //게시물 좋아요 실행
	
	@Delete("delete from boardlike where board_sn=${bno} and writer=${mno}")
	void offlike(@Param("bno")int bno,@Param("mno")int mno); //게시물 좋아요 취소
	
	@Select("select count(*) from boardlike where board_sn=${bno} and writer=${mno}")
	int likeis(@Param("bno")int bno,@Param("mno")int mno);//좋아요 여부

	@Select("select * from comment join member on comment.writer = member.sn where board_sn = ${sn} order by comment.sn desc limit 0,#{size};")
	@Results(value = {
			@Result(property = "sn", column = "comment.sn"),
			@Result(property = "contents", column = "contents"),
			@Result(property = "writer.profile", column = "profile"),
			@Result(property = "writer.name", column = "name"),
			@Result(property = "writer.id", column = "id"),
			@Result(property = "writer.sn", column = "writer"),
			})
	List<Comment> findCommentBySn(@Param("sn")int sn,@Param("size")int size);//댓글출력

	@Select("select count(*) from comment where board_sn=${sn}")
	int comments(@Param("sn")int sn); //게시물당 댓글 갯수
	
	@Insert("insert into comment(board_sn,writer,contents)values(#{board.sn},#{writer.sn},#{contents})")
	@SelectKey(statement="select last_insert_id()", keyProperty="sn", before=false, resultType=int.class)
	void savecomment(Comment comment); //댓글등록
	
	@Select("select * from comment join member on comment.writer = member.sn where comment.sn = ${sn};")
	@Results(value = {
			@Result(property = "sn", column = "comment.sn"),
			@Result(property = "contents", column = "contents"),
			@Result(property = "writer.profile", column = "profile"),
			@Result(property = "writer.sn", column = "writer"),
			@Result(property = "writer.name", column = "name"),
			})
	Comment findComment(@Param("sn")int sn);// 댓글하나출력

	@Delete("delete from comment where sn=${sn}")
	void 댓글삭제(@Param("sn")int sn); //댓글삭제
	
	@Select("select count(*) from board LEFT JOIN friend ON board.writer = friend.my_sn join state on friend.friend_sn=state.sn where friend.friend_sn=${sn} and (board.state='전체' or board.state='친구') and wdate>viewtime order by board.sn desc")
	int checknewboard(@Param("sn")int sn); //새로생긴보드갯수확인
	
	//상태:광고 게시물출력
	@Select("select * from attach join board on board.sn = attach.board_sn where board.state='광고' order by rand() limit 1")
	@Results(value = {
			@Result(property = "sn", column = "sn"),
			@Result(property = "board.contents", column = "contents"),
			})
	Attach Advertising();
	
	@Select("select count(*) from board LEFT JOIN friend ON board.writer = friend.my_sn join state on friend.friend_sn=state.sn where friend.friend_sn=${sn} and (board.state='전체' or board.state='친구') and wdate>lastviewtime and  wdate<viewtime")
	int numberofboard(@Param("sn")int sn); //전체 게시물갯수
	
	@Delete("delete from board where sn=${sn}")
	void deleteboard(@Param("sn")int sn); //댓글삭제
	
	//보드번호로 게시물찾기
	@Select("select * from board where sn=${sn}")
	@Results(value = {
			@Result(property = "sn", column = "sn"),
			@Result(property = "contents", column = "contents"),
			@Result(property = "wdate", column = "wdate"),
			@Result(property = "state", column = "state"),
			@Result(property = "writer", column = "writer", one=@One(select = "com.lec206.acebook.dataservice_member.IMemberMapper.findSimple")),
			//@Result(property = "attachs", javaType = List.class, column = "sn",many=@Many(select = "com.lec206.acebook.dataservice_board.IAttachMapper.load"))
			})
	Board findboard(@Param("sn")int sn);
	
	//게시물수정
	@Update("UPDATE board SET contents=#{contents}, state=#{state} where sn=${sn}")
	void modifyboard(Board board);
	
	//게시물신고
	@Update("UPDATE board SET state='차단' where sn=${sn}")
	void reportboard(@Param("sn")int sn);
	
	//게시물공유등록
	@Insert("insert into sharing values(${to},${get})")
	void savesharing(@Param("to")int to,@Param("get")int get); 
	
	//게시물번호로 공유번호 가져오기
	@Select("select getboard from sharing where board_sn=${sn};")
	int getsharingsn(@Param("sn")int sn); 
	
	//공유삭제
	@Delete("delete from sharing where board_sn=${sn}")
	void deletesharing(@Param("sn")int sn); 
	
}
