package com.lec206.acebook.dataservice_board;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.lec206.acebook.common_board.Attach;

@Mapper
public interface IAttachMapper {
	
	//그림파일 저장
	@Insert({"<script>", 
		"insert into attach(filename,filesize,board_sn) values ",
		"<foreach collection='attachs' item='attach' index='index' separator=','>", 
		"(#{attach.filename},#{attach.filesize},#{attach.board.sn})",	
		"</foreach>",
		"</script>"
		})
	void saveAttachs(@Param(value="attachs")List<Attach> attachs);
	
	//그림파일 불러오기
	@Select("select * from attach where board_sn = ${sn}")
	List<Attach> load(@Param("sn")int sn);
	
	//저장된 첨부사진들 찾기
	@Select("select * from attach join board on board.sn = attach.board_sn join member on board.writer = member.sn where attach.sn =${sn};")
	@Results(value= {
			@Result(property = "sn", column="attach.sn"),
			@Result(property = "filename", column="filename"),
			@Result(property = "filesize", column="filesize"),
			@Result(property = "board.sn", column="board_sn"),
			@Result(property = "board.writer.id", column="id"),
			})
	Attach findBySn(@Param("sn") int sn);

	@Select("select attach.sn from attach join board on attach.board_sn = board.sn where board.sn=${sn}")
	int findattachsn(@Param("sn")int sn);//보드번호로 게시물번호찾기
	
	@Delete("delete from attach where sn=${sn}")
	void deleteAttach(@Param("sn")int sn); //첨부파일삭제
	
	
	
}