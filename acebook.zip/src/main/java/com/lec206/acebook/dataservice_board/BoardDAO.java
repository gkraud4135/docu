package com.lec206.acebook.dataservice_board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lec206.acebook.common_board.Attach;
import com.lec206.acebook.common_board.Board;
import com.lec206.acebook.common_board.BoardLike;
import com.lec206.acebook.common_board.Comment;
import com.lec206.acebook.dataservice_contents.ILoginMapper;
import com.lec206.acebook.util.게시물상태;

@Repository
public class BoardDAO implements IBoardDAO {

	@Autowired IBoardMapper boardMapper;
	@Autowired IAttachMapper attachMapper;
	//학명이 추가코드, 로그인정보에 뷰타임 넣을려고 넣은거같음	
	@Autowired ILoginMapper loginMapper;
	
	@Override
	@Transactional
	public int save(Board board) {
			
		int getsn = 0;
		getsn = board.getSn();
		boardMapper.save(board);
		if(board.getState()==게시물상태.공유) {
		boardMapper.savesharing(board.getSn(),getsn);//저장된게시물에 가져온게시물을연결
		}
		
		if(board.getAttachFiles()!=null) {
			
			System.out.println("첨부파일존재 from BoardDAO");
			System.out.println(board.getSn()+"게시물번호!");
			attachMapper.saveAttachs(board.getAttachs());
		}
		
		return board.getSn();
	}

	@Override
	@Transactional
	public Attach findBySn(int sn) {
		
		Attach attach = attachMapper.findBySn(sn);
		return attach;
	}

	@Override
	@Transactional
	public int findattachsn(int sn){//보드번호로 게시물번호 가져오기
		
		return attachMapper.findattachsn(sn);
	}

	
	@Override
	@Transactional
	public List<Board> selectAll() {

		return boardMapper.selectAll();
	}
	

	@Override
	@Transactional
	public List<Board> myboard(int sn,int size){
			
		return boardMapper.myboard(sn,size);
	}

	@Override
	@Transactional
	public List<Attach> load(int boardsn) {
		
		return attachMapper.load(boardsn);
	}
	
	@Override
	@Transactional
	public List<BoardLike> boardlike(int sn) { //좋아요vo 출력
		
		return boardMapper.boardlike(sn);
	}
	
	@Override
	@Transactional
	public int likes(int no) {//게시물당 좋아요 갯수
		return boardMapper.likes(no);
	}
	
	@Transactional
	@Override
	public void onoffLike(int bno, int mno,int no){// 좋아요 실행,취소 여부
		if(no==1) {//no 1 일시 좋아요 취소
			boardMapper.offlike(bno, mno);
		}
		else {//no 0일시 좋아요 실행
			boardMapper.onlike(bno, mno);
		}

	}
	
	@Transactional
	@Override
	public int likeis(int bno, int mno) { //처음화면 좋아요 여부
		return boardMapper.likeis(bno, mno);
	}
	
	@Transactional
	@Override
	public List<Comment> findCommentBySn(int sn,int size) { //댓글출력
		return boardMapper.findCommentBySn(sn,size);
	}
	
	@Transactional
	@Override
	public int comments(int sn) { //댓글갯수출력
		return boardMapper.comments(sn);
	}
	
	@Transactional
	@Override 
	public void savecomment(Comment comment) { //댓글등록
		boardMapper.savecomment(comment);
	}
	
	@Transactional
	@Override
	public Comment findComment(int sn) { //댓글하나출력
		return boardMapper.findComment(sn); 
	}

	@Transactional
	@Override
	public void deletecomment(int sn) { //댓글삭제
		boardMapper.댓글삭제(sn); 
	}
	
	@Transactional
	@Override 
	public List<Board> mainboard(int sn,int size) { //나의메인게시물
		 return boardMapper.mainboard(sn, size);
	}
	
	@Override
	@Transactional
	public void viewtimeupdate(int sn) {//mainboard.jsp 접속시마다 state 상태변경
		
		loginMapper.viewtimeupdate(sn);
		loginMapper.lasttimeupdate(sn);
		System.out.println("메인페이지 시간갱신");
		
	}
	
	@Transactional
	@Override
	public int checknewboard(int sn) { //새로생긴보드갯수확인
		return boardMapper.checknewboard(sn);
	}
	
	@Transactional
	@Override
	public int numberofboard(int sn) { //새로생긴보드갯수확인
		return boardMapper.numberofboard(sn);
	}
	
	@Transactional
	@Override
	public Attach Advertising() { //광고 게시물출력
		return boardMapper.Advertising();
	}
	
	@Transactional
	@Override
	public void deleteboard(int sn) { //게시물삭제
		boardMapper.deleteboard(sn); 
	}
	
	@Transactional
	@Override
	public Board findboard(int sn) { //게시물한개
		return boardMapper.findboard(sn);
	}
	
	@Transactional
	@Override
	public void deleteAttach(int sn) { //첨부파일삭제
		attachMapper.deleteAttach(sn); 
	}
	
	@Transactional
	@Override
	public void modifyboard(Board board) { //게시물수정
		boardMapper.modifyboard(board);
		if(board.getAttachFiles()!=null) {
			
			System.out.println("첨부파일존재 from BoardDAO");
			System.out.println(board.getSn()+"게시물번호!");
			attachMapper.saveAttachs(board.getAttachs());
		}
	}
	
	@Transactional
	@Override
	public void reportboard(int sn) { //첨부파일삭제
		boardMapper.reportboard(sn); 
	}
	
	@Override
	public int getsharingsn(int sn) { //게시물번호로 공유번호 가져오기
		return boardMapper.getsharingsn(sn);
	}
	
	@Transactional
	@Override
	public void deletesharing(int sn) { //공유삭제
		boardMapper.deletesharing(sn);
	}
	
}
