package com.lec206.acebook.util;

public enum 로그인상태 {
	
	접속중,
	로그오프,
	기타용무중

}
