package com.lec206.acebook.util;

public enum 친구상태 {
	
	신청중,
	친구,
	차단

}
