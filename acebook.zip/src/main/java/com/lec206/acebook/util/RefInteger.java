package com.lec206.acebook.util;

public class RefInteger {
	public int value;
	

}
