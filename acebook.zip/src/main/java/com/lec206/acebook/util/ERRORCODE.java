package com.lec206.acebook.util;

public enum ERRORCODE {
	
	NORMAL,
	NETWORK_ERROR,
	SQL_ERROR,
	존재하지않는회원,
	이메일형식,
	아이디공백,
	중복,
	신청중,
	첫로그인
	

}