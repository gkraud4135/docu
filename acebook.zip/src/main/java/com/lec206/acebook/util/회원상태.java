package com.lec206.acebook.util;

public enum 회원상태 {
	
	승인중,
	회원,
	탈퇴

}
