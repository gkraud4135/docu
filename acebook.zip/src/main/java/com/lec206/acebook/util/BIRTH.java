package com.lec206.acebook.util;

public enum BIRTH {
	
   서울,
   인천,
   대전,
   대구,
   광주,
   울산,
   부산,
   제주도,
   울릉도,
   독도,
   경기도,
   강원도,
   전라북도,
   전라남도,
   경상북도,
   경상남도,
   충청북도,
   충청남도 

}