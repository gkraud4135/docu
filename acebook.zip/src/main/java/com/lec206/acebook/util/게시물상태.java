package com.lec206.acebook.util;

public enum 게시물상태 {
	
	전체,
	친구,
	프로필,
	광고,
	차단,
	공유,
	백프로필

}