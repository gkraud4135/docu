package com.lec206.acebook.util;

public enum GENDER {
	
	남자,
	여자

}
