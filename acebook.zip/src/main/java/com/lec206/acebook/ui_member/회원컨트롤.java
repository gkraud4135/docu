package com.lec206.acebook.ui_member;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.lec206.acebook.common_member.Member;
import com.lec206.acebook.common_member.MemberPost;
import com.lec206.acebook.common_member.MemberSchool;
import com.lec206.acebook.manage_member.I회원관리;
import com.lec206.acebook.util.BusinessResult;
import com.lec206.acebook.util.ERRORCODE;
import com.lec206.acebook.util.GENDER;

@Controller
public class 회원컨트롤{
	
	@Autowired I회원관리 회원관리자;
	
	@GetMapping("member")
	public String 회원등록준비() {
	         
		//1.요청페이지(회원등록창.jsp)
	
		return "member/회원등록창";
	      
	}
	
	@PostMapping("member")
	public ModelAndView 회원등록(Member member) {
	         
	         //1.요청페이지(회원등록결과통보.jsp)
	         ModelAndView mv = new ModelAndView();
	         
	         //2.업무
	            BusinessResult br = 회원관리자.회원등록준비(member);
	            
	            //비정상코드입력시
	            if(br.getCode()!=ERRORCODE.NORMAL) {}
	                           
	         //3.경로지정
	         
	         mv.setViewName("acebook");
	         mv.addObject("member", member);
	         System.out.println(mv.getViewName()+"으로 이동중");
	         
	      return mv;
	      
	   }
	
	@GetMapping("id")
	public String get중복검사() {
				
			//1.요청페이지(아이디중복검사창.jsp)
				
			//2.업무
				
			//3.경로지정
		
				System.out.println("중복검사창으로 이동중");
				
		return "/member/아이디중복검사창";

		}
	
	@PostMapping("id")
	public ModelAndView post중복검사(String id) {
				
			//1.요청페이지(아이디중복검사창.jsp)
			ModelAndView mv = new ModelAndView();
			
			//에러코드처리시에 뷰페이지 설정을 위해서, 위에다가 뷰페이지를 지정해줌.
			mv.setViewName("/member/아이디중복검사창");
			
				
			//2.업무
			//사용가능==true : 아이디중복,사용불가 
			//사용가능==false : 아이디사용가능
			boolean 사용가능 = true;

			BusinessResult br = 회원관리자.중복검사(id);
			
			//비정상코드입력시
			if(br.getCode()!=ERRORCODE.NORMAL) {
				if(br.getCode()==ERRORCODE.아이디공백) {
					
					mv.addObject("msg",br.getMsg());
					mv.addObject("use",사용가능);
					mv.addObject("id",id);
					
					return mv;
					
				}
				
				if(br.getCode()==ERRORCODE.이메일형식) {
					
					mv.addObject("msg",br.getMsg());
					mv.addObject("use",사용가능);
					mv.addObject("id",id);
	
					return mv;
					
				}
				
			}
				
			//3.경로지정
				mv.addObject("msg","사용가능한 아이디입니다.");
				mv.addObject("use",사용가능=false);
				mv.addObject("id",id);

				System.out.println(mv.getViewName()+"으로 이동중");
					
				return mv;
			
		}
	
	@GetMapping("addschool")
	public String get학교등록() {
				
			//1.요청페이지(.jsp)
				
			//2.업무
					
				//비정상코드입력시
				//if(br.getCode()!=ERRORCODE.NOMAL) {}
										
			//3.경로지정

				//System.out.println("viewname 으로 이동중");
				
			return "/member/학교등록";
			
		}

	@PostMapping("addschool")
	public ModelAndView post학교등록(MemberSchool memberschool, HttpSession session) {
				
			//1.요청페이지(.jsp)
			ModelAndView mv = new ModelAndView();
			int 회원번호 = (int)session.getAttribute("sn");
				
			//2.업무
				BusinessResult br = 회원관리자.회원정보조회(회원번호);
				//학교정보 저장전에 session에서 회원번호로 회원 객체정보저장
				memberschool.setSn((Member)br.getValue());
				//만들어진 회원학교정보 저장
				br = 회원관리자.학교등록(memberschool);		
				//비정상코드입력시
				if(br.getCode()!=ERRORCODE.NORMAL) {}
										
			//3.경로지정
				mv.setViewName("/member/주소등록");
				//mv.addObject("key", value);
				//System.out.println(mv.getViewName()+"으로 이동중");
				
			return mv;
			
		}
	
	@GetMapping("addpost")
	public String get주소등록() {
				
			//1.요청페이지(주소등록.jsp)
				
			//2.업무
					
				//비정상코드입력시
				//if(br.getCode()!=ERRORCODE.NORMAL) {}
										
			//3.경로지정

				//System.out.println("viewname 으로 이동중");
				
			return "/member/주소등록";
			
		}
	
	@PostMapping("addpost")
	public ModelAndView post주소등록(MemberPost memberpost, HttpSession session) {
				
			//1.요청페이지(주소등록.jsp)
			ModelAndView mv = new ModelAndView();
			int 회원번호 = (int)session.getAttribute("sn");
				
			//2.업무
			BusinessResult br = 회원관리자.회원정보조회(회원번호);
			//주소정보 저장전에 session에서 회원번호로 회원 객체정보저장
			memberpost.setSn((Member)br.getValue());
			Member member = (Member)br.getValue();
			//만들어진 회원주소정보 저장
			br = 회원관리자.주소등록(memberpost);
			if(br.getCode()!=ERRORCODE.NORMAL) {}
			
			//3.경로지정
				//일딴 메인으로 해둠
				mv.setViewName("main");
				mv.addObject("member", member);
				mv.addObject("memberpost", memberpost);
				//System.out.println(mv.getViewName()+"으로 이동중");
				
			return mv;
			
		}

	@ResponseBody
    @PostMapping("selectuser")
    public  List<Member> idCheck(@RequestParam String name){
       List<Member> users = null;
       
       try{
    	   
          String search=name.trim();
        
          users=(List<Member>)회원관리자.유저출력(search).getValue();
       }
       
       catch(Exception e){System.out.println("error");}
       
       return users;
    }
	
	   @GetMapping("profile")
	   public ModelAndView get프로필(HttpSession session) {
	      
	      //1.요청페이지(.jsp)   
	      ModelAndView mv = new ModelAndView();
	      //2.업무
	      int sn = (int)session.getAttribute("sn");
	      BusinessResult br = 회원관리자.회원정보조회(sn);
	      Member member = (Member)br.getValue();
	      //비정상코드입력시
	      if(br.getCode()!=ERRORCODE.NORMAL) {}
	      System.out.println(member.getProfile());
	      //3.경로지정
	      mv.setViewName("/board/profile");
	      mv.addObject("profile", member.getProfile());        
	      System.out.println(mv.getViewName()+"으로 이동중");
	         
	      return mv;
	      
	   }
	   
	   ////////////////07 -13 추가!!
	   @GetMapping("change")
	   public String get(HttpSession session) {
		   		   		   
		 //1.요청페이지(상세정보변경창.jsp)
		   
		   return "/member/상세정보변경창";		   
	   }
	   
	   @GetMapping("changeschool")
	   public ModelAndView get학교변경(HttpSession session) {
		   		   		   
		 //1.요청페이지(학교변경창.jsp)
		   	ModelAndView mv = new ModelAndView();
		   	int 회원번호 = (int)session.getAttribute("sn");
		   
		 //2.업무
		   	BusinessResult br = 회원관리자.회원정보조회(회원번호);
		  // 학교변경창 가기전 기존에 있던 학교 정보를 학교변경창 value값에 넣어주기위한 작업
		   	Member member = (Member)br.getValue();
		   	System.out.println("회원초등학교"+member.getSchool().getRow());
		 //3.경로지정
		   	mv.setViewName("/member/학교변경창");
		   	mv.addObject("member", member);
		   
		   return mv;		   
	   }
	   
	   @PostMapping("changeschool")
		public String post학교변경(MemberSchool memberschool, HttpSession session) {
					
				//1.요청페이지(.jsp)
		   			ModelAndView mv = new ModelAndView();
		   			int 회원번호 = (int)session.getAttribute("sn");
					
				//2.업무
					BusinessResult br = 회원관리자.회원정보조회(회원번호);
					//학교정보 저장전에 session에서 회원번호로 회원 객체정보저장
					memberschool.setSn((Member)br.getValue());
					//만들어진 회원학교정보 저장
					br = 회원관리자.학교등록(memberschool);		
					//비정상코드입력시
					if(br.getCode()!=ERRORCODE.NORMAL) {}
											
				//3.경로지정
					mv.addObject("member", (Member)br.getValue());
					
				return "member/상세정보변경완료";
				
			}
	   
	   @GetMapping("changepost")
	   public ModelAndView get주소변경(HttpSession session) {
		   
		   
		 //1.요청페이지(주소변경창.jsp)
		   ModelAndView mv = new ModelAndView();
		   int 회원번호 = (int)session.getAttribute("sn");
		 //2.업무
			BusinessResult br = 회원관리자.회원정보조회(회원번호);
			//주소변경창 가기전 기존에 있던 주소 정보를 주소변경창 value값에 넣어주기위한 작업
			Member member = (Member)br.getValue();
			System.out.println("=============회원우편번호"+member.getPost().getAddress());
		 //3.경로지정
			mv.setViewName("/member/주소변경창");
			mv.addObject("member", member);
			return mv;
		   
	   }
	   
	   @PostMapping("changepost")
		public ModelAndView post주소변경(MemberPost memberpost, HttpSession session) {
					
				//1.요청페이지(주소등록.jsp)
				ModelAndView mv = new ModelAndView();
				int 회원번호 = (int)session.getAttribute("sn");
					
				//2.업무
				BusinessResult br = 회원관리자.회원정보조회(회원번호);
				//주소정보 저장전에 session에서 회원번호로 회원 객체정보저장
				memberpost.setSn((Member)br.getValue());
				//만들어진 회원주소정보 저장
				br = 회원관리자.주소등록(memberpost);
				if(br.getCode()!=ERRORCODE.NORMAL) {}
											
				//3.경로지정
				mv.setViewName("/member/상세정보변경완료");
				mv.addObject("member", memberpost);
					
				return mv;
				
			}

	   
	   
	   //테스트 코드 영역{
		@GetMapping("testmember")
		public String get회원테스트() {
					
				//1.요청페이지(.jsp)
					
				//2.업무
					
					//회원 더미데이터 작성 랜덤이름 작성
					  String[] 성 = {"김","박","이","최","오","성","진","목","판","강","윤"};
					  String 상현 = "상현"; 
					  String 성상현; 
					  String 학명 = "학명"; 
					  String 이학명; 
					  String 영웅 = "영웅";
					  String 이영웅; 
					  List<String> 이름들 = new ArrayList<String>();
					  for(int i=0; i<성.length; i++) {
					  
					  성상현 = 성[i]+상현;
					  이름들.add(성상현);
					  이학명 = 성[i]+학명;
					  이름들.add(이학명);
					  이영웅 = 성[i]+영웅;
					  이름들.add(이영웅);

					 }
					  //랜덤이름 작성완료
					  
					  //랜덤출생년월일 작성
					  List<String> 생년월일들 = new ArrayList<String>();
					  for(int i=1980; i<1999; i++) {
						  String 형변환 = String.valueOf(i);
						  형변환 = 형변환+"-"+(int)((Math.random()*10000)%10+1)+"-"+(int)((Math.random()*30000)%30+1);
						  String 생년월일 = String.valueOf(형변환);
						  생년월일들.add(생년월일);
						  
					  }
					  
					  for(int i = 0; i<50; i++) {
						  
						  Member member = new Member();
						  ArrayList<String> 랜덤이름 = new ArrayList<String>(); 
						  ArrayList<String> 랜덤생일 = new ArrayList<String>(); 

						  int randomname = (int)(Math.random()*이름들.size());
						  랜덤이름.add(이름들.get(randomname));
						  System.out.println("입력받은 아이디 = test"+i);
						  member.setId("test"+i);
						  //i번째에 추가된 랜덤이름을 맴버이름으로 저장
						  member.setName(랜덤이름.get(0));
						  member.setPassword("1234");
						  member.setGender(GENDER.남자);
						  int randomage = (int)(Math.random()*생년월일들.size());
						  랜덤생일.add(생년월일들.get(randomage));
						  //i번째에 추가된 랜덤생일을 맴버생일로 저장
						  member.setAge(랜덤생일.get(0));
						  
						  BusinessResult br = 회원관리자.회원등록준비(member);
						  
					  }
					 
					

					

					//비정상코드입력시
					//if(br.getCode()!=ERRORCODE.NOMAL) {}
											
				//3.경로지정

					//System.out.println("viewname 으로 이동중");
					
				return " ";
				
			}
		
		@GetMapping("testschool")
		public String get회원학교테스트() {
					
				//1.요청페이지(.jsp)
					
				//2.업무
				BusinessResult br = 회원관리자.전체회원출력();
				
				List<Member> members = (List<Member>)br.getValue();
				
				MemberSchool memberschool = null;
				
				for(Member member : members) {
					
					if(member.getSn()<25) {

				memberschool = new MemberSchool();
				
				memberschool.setSn(member);
				memberschool.setRow("구로초등학교");
				memberschool.setMiddle("구로중학교");
				memberschool.setHigh("구로고등학교");
				memberschool.setUniversity("대림대학교");
				
				System.out.println(memberschool.getSn().getSn());
				System.out.println(memberschool.getRow());
				
				br = 회원관리자.학교등록(memberschool);


					} else {
						
						memberschool = new MemberSchool();
						
						memberschool.setSn(member);
						memberschool.setRow("영웅초등학교");
						memberschool.setMiddle("영웅중학교");
						memberschool.setHigh("영웅고등학교");
						memberschool.setUniversity("영웅대학교");
						
						br = 회원관리자.학교등록(memberschool);
						
					}
					
				}
				
				return " ";
				
			}
		//테스트코드영역 종료}

	}